package com.users;

import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.users.utils.RoleCheck;

@RestController
@RequestMapping("/users")
public class UserController {

    UserService userService;
    RoleCheck roleCheck;

    public UserController(UserService userService,RoleCheck roleCheck) {
        this.userService = userService;
        this.roleCheck = roleCheck;
    }

    @GetMapping()
    public ResponseEntity<Map<String, Object>> getAllUsers(@RequestBody Map<String,Object> requestBody) {
        if(!requestBody.get("role").toString().equalsIgnoreCase("admin")) {
            return new ResponseEntity<>(Map.of("status", "error", "message", "Unauthorized access"), HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> response = userService.getAllUsers();
        if(response.get("status")=="error") {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getUserById(@PathVariable String id,@RequestBody Map<String,Object> requestBody) {
        boolean isAuthorized = roleCheck.checkAccess(requestBody);
        if(!isAuthorized) {
            return new ResponseEntity<>(Map.of("status", "error", "message", "Unauthorized access"), HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> response = userService.getUserById(Long.parseLong(id));
        if(response.get("status")=="error") {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable String id, @RequestBody Map<String,Object> requestBody) {
        boolean isAuthorized = roleCheck.checkAccess((Map<String,Object>)requestBody.get("claims"));
        if(!isAuthorized) {
            return new ResponseEntity<>(Map.of("status", "error", "message", "Unauthorized access"), HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> response = new HashMap<>();
        // response.put("message", "User updated successfully for ID: " + id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable String id,@RequestBody Map<String,Object> requestBody) {
        boolean isAuthorized = roleCheck.checkAccess(requestBody);
        if(!isAuthorized) {
            return new ResponseEntity<>(Map.of("status", "error", "message", "Unauthorized access"), HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> response = userService.deleteUser(Long.parseLong(id));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
}
